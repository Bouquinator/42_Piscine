/* ************************************************************************** */
/*                                                                            */
/*                                                         ::::::::           */
/*   ft_atoi.c                                           :+:    :+:           */
/*                                                      +:+                   */
/*   By: mgrossen <marvin@42.fr>                       +#+                    */
/*                                                    +#+                     */
/*   Created: 2026/06/26 12:05:21 by mgrossen       #+#    #+#                */
/*   Updated: 2026/06/26 14:54:22 by mgrossen       ########   odam.nl        */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	issspace(char test)
{
	printf("issspace start");
	if (test == ' ' || test == '\f' || test == '\n')
	{
		printf("RETURN 1");
		return (1);
	}
	if (test == '\r' || test == '\t' || test == '\v')
	{
		return (1);
		printf("return 1");
	}
	else
	{
		printf("return 0");
		return(0);
	}
}

int	isnegative(char *str)
{
	int	i;
	int	m;

	i = 0;
	m = 0;
	while(str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			m++;
		i++;
	}
	if ((m % 2) == 0)
		return(0);
	return(1);
}

int	ft_atoi(char *str)
{
	int	i;
	int	numb;

	i = 0;
	while (issspace(str[i]) != 0)
	{
		i++;
	}
	printf("issspace fait position i = %d\n", i);
	str = &str[i];
	printf("nouvelle string = %s\n", str);
	i = 0;
	while (str[i] >= '0' && str[i] <= '9')
	{
		printf("pour %d, %d", i, (str[i] - 48));
		numb = numb + (str[i] - 48);
		if (str[(i + 1)] >= '0' && str[i+1] <= '9')
			numb = numb * 10;
		i++;
	}

	printf("nombre temporaire = %d\n", numb);

	if (isnegative(str) == 1)
		numb = numb * (-1);
	printf("Nombre final = %d\n", numb);
	return(numb);
}

int	main(void)
{
	printf("%d", ft_atoi(" ---+--+1234ab567"));
}
